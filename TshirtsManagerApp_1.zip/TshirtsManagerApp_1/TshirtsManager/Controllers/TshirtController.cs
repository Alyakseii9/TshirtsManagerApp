﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TshirtsManager.Data;
using TshirtsManager.Data.Models;

namespace TshirtsManager.Controllers
{
    [Route("api/Tshirt")]
    [ApiController]
    public class TshirtController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TshirtController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Tshirt - default
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Tshirt>>> GetTshirt()
        {
            if (_context.Tshirt == null)
            {
                return NotFound("No Data Found");
            }
            return await _context.Tshirt.Where(static e => !e.Deleted && !e.Done); ToListAsync();
        }

        private void ToListAsync()
        {
            throw new NotImplementedException();
        }

        // GET: api/Tshirt/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Tshirt>> GetTshirt(int id)
        {
            if (_context.Tshirt == null)
            {
                return NotFound("No Data Found");
            }

            var tshirt = await _context.Tshirt.FindAsync(id);

            if (tshirt == null)
            {
                return NotFound("No Data Found");
            }

            return tshirt;
        }

        // PUT: api/Tshirt/5
        // To protect from overpoting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTshirt(int id, Tshirt tshirt)
        {
            if (id != tshirt.ID)
            {
                return BadRequest("You are trying to modify the wrong Tshirt.");
            }

          //  _context.Entry(tshirt).State = EntityState.Modified;

            try
            {
                   Tshirt entry_ = await _context.Tshirt.FindAsync(tshirt.ID);

                if (entry_.Names !=tshirt.Names)
                {
                    entry_.Names = tshirt.Names;
                }

                if (entry_.Description != tshirt.Description)
                {
                    entry_.Description = tshirt.Description;
                }

                if (entry_.Price != tshirt.Price)
                {
                    entry_.Price = tshirt.Price;
                }

                if (entry_.Rating != tshirt.Rating)
                {
                    entry_.Rating = tshirt.Rating;
                }

                if (entry_.Done != tshirt.Done)
                {
                    entry_.Done = tshirt.Done;
                }

                if (entry_.Deleted != tshirt.Deleted)
                {
                    entry_.Deleted = tshirt.Deleted;
                }

                if (entry_.Date != tshirt.Date)
                {
                    entry_.Date = tshirt.Date;
                }

                if (entry_.Time != tshirt.Time)
                {
                    entry_.Time = tshirt.Time;
                }

              //  entry_ = tshirt;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TshirtExists(id))
                {
                    return NotFound("The tshirt with the Id" + " " + id + " Does not exist!");
                }
                else
                {
                    throw;
                }
            }

            return Ok("Tshirt updates successfully!");
        }

        // POST: api/Tshirt
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Tshirt>> PostTshirt(Tshirt tshirt)
        {
            if (_context.Tshirt == null)
            {
                return Problem("Entity set 'Tshirts' is nul");
            }

            try
            {
                _context.Tshirt.Add(tshirt);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException e)
            {
                return BadRequest("Cold not create new Tshirt: " + e.Message);
            }

            return CreatedAtAction("GetTshirt", new { id = tshirt.ID }, tshirt);
        }

        // DELETE: api/Tshirt/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTshirt(int id)
        {
            if (_context.Tshirt == null)
            {
                return NotFound("No Data Found!");
            }
            var tshirt = await _context.Tshirt.FindAsync(id);
            if (tshirt == null)
            {
                return NotFound("No tshirt with the ID " + id);
            }

            _context.Tshirt.Remove(tshirt);
            await _context.SaveChangesAsync();

            return Ok("Tshirt deleted successfully!");
        }

        private bool TshirtExists(int id)
        {
            return _context.Tshirt.Any(e => e.ID == id);
        }
    }
}
