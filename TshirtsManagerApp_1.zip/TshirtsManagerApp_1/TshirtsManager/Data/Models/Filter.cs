﻿namespace TshirtsManager.Data.Models
{
    public class Filter
    {
        public byte? Rating { get; set; } = null;

        public string? SpecifiedTime { get; set; } = null;

        public DataTime? SpecifiedDate { get; set; } = null;
        public DataTime? StartDate { get; set; } = null;
        public DataTime? EndDate { get; set; } = null;

        public bool? All { get; set; } = false;
        public bool? Done { get; set; } = false;
        public bool? Deleted { get; set; } = false;

    }

    public class DataTime
    {
    }
}
