﻿using Microsoft.EntityFrameworkCore;
using TshirtsManager.Data.Models;

namespace TshirtsManager.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Tshirt> Tshirt { get; set; }
    }
}
